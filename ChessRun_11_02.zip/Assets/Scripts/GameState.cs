﻿using UnityEngine;
using System.Collections;

public class GameState {

	public static string MY_TURN_NO_HIGHLIGHT = "my_turn_no_highlight";
	public static string MY_TURN_HIGHLIGHT_MOVES = "my_turn_highlight_moves";
	public static string LEVEL_COMPLETE = "level_complete";
};

