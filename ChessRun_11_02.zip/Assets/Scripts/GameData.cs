﻿using UnityEngine;
using System.Collections;

public class GameData : MonoBehaviour {

	public static int choosedLevel;
}
