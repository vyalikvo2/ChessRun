﻿public class Relation {
    public static int SELF = 0;
    public static int ENEMY = 1;
    public static int NEURAL = 2;
    public static int BUILDING = 3;
}