﻿using UnityEngine;
using UnityEngine.UI;


public class GameUI : MonoBehaviour {
	
	[SerializeField] public Text Txt_level;

}
