﻿using System.Runtime.CompilerServices;

[assembly: InternalsVisibleTo("Unity.VectorGraphics.Editor")]
[assembly: InternalsVisibleTo("Unity.VectorGraphics.Tests")]
[assembly: InternalsVisibleTo("Unity.VectorGraphics.Editor.Tests")]