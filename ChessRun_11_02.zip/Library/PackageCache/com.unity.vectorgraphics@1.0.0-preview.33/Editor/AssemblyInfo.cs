﻿using System.Runtime.CompilerServices;

[assembly: InternalsVisibleTo("Unity.VectorGraphics.Editor.Tests")]