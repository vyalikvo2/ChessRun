﻿public class ZIndex  {

	public static int PIECES_MY = 1;
	public static int PIECES_HIGHLIGHT = 5;
	public static int DRAGGING_PIECE = 6;
	public static int UI_OVER_GAME_1 = 6;
	
}
