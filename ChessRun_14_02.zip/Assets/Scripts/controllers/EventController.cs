﻿using UnityEngine;

public class EventController : MonoBehaviour
{
   public delegate void ActionEvent(GameAction action);
}
